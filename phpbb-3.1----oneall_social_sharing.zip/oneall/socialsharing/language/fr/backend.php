<?php
/**
*
* OneAll Social Sharing extension for the phpBB Forum Software package.
* French translation by Galixte (http://www.galixte.com)
*
* @copyright (c) 2013-2015 <http://www.oneall.com> - All rights reserved.
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

// Social Sharing Backend.
$lang = array_merge($lang, array(
	'OA_SOCIAL_SHARING_ACP' => 'Passerelle de connexion OneAll',
	'OA_SOCIAL_SHARING_ACP_SETTINGS' => 'Paramètres',
	'OA_SOCIAL_SHARING_API_AUTODETECT' => 'Détection automatique de la connexion à l’API',
	'OA_SOCIAL_SHARING_API_CONNECTION' => 'Connexion à l’API',
	'OA_SOCIAL_SHARING_API_CONNECTION_HANDLER' => 'Gestionnaires de connexion à l’API',
	'OA_SOCIAL_SHARING_API_CONNECTION_HANDLER_DESC' => 'OneAll est un gestionnaire de connexions aux API.',
	'OA_SOCIAL_SHARING_API_CREDENTIALS_CHECK_COM' => 'Impossible de se connecter à l’API. Est-ce que la connexion à l’API a été configurée correctement ?',
	'OA_SOCIAL_SHARING_API_CREDENTIALS_FILL_OUT' => 'Merci de remplir chacun des champs ci-dessus.',
	'OA_SOCIAL_SHARING_API_CREDENTIALS_KEYS_WRONG' => 'Les certificats d’API sont incorrects, merci de vérifier les clés publiques et privées.',
	'OA_SOCIAL_SHARING_API_CREDENTIALS_OK' => 'Les paramètres sont corrects - Ne pas oublier de sauvegarder les changements !',
	'OA_SOCIAL_SHARING_API_CREDENTIALS_SUBDOMAIN_WRONG' => 'Le sous domaine n’existe pas. A t-il été rempli correctement ?',
	'OA_SOCIAL_SHARING_API_CREDENTIALS_TITLE' => 'Certificats d’API - <a href="https://app.oneall.com/applications/" class="external">Cliquer ici pour créer et voir ses certificats d’API</a>',
	'OA_SOCIAL_SHARING_API_CREDENTIALS_UNKNOW_ERROR' => 'Réponse inconnue - Merci de s’assurer que la connexion est établie !',
	'OA_SOCIAL_SHARING_API_CREDENTIALS_USE_AUTO' => 'Le gestionnaire de connexion ne semble pas fonctionner. Merci d’utiliser la détection automatique.',
	'OA_SOCIAL_SHARING_API_DETECT_CURL' => 'CURL a été détecté sur le port %s - Ne pas oublier de sauvegarder les changements !',
	'OA_SOCIAL_SHARING_API_DETECT_FSOCKOPEN' => 'FSOCKOPEN a été détecté sur le port %s - Ne pas oublier de sauvegarder les changements !',
	'OA_SOCIAL_SHARING_API_DETECT_NONE' => 'La connexion a échouée ! Votre pare-feu doit permettre les requêtes sortantes soit sur le port 80 ou 443.',
	'OA_SOCIAL_SHARING_API_PORT' => 'Port de connexion à l’API',
	'OA_SOCIAL_SHARING_API_PORT_DESC' => 'Votre pare-feu doit autoriser les requêtes sortantes sur un le port 80 ou 443.',
	'OA_SOCIAL_SHARING_API_PRIVATE_KEY' => 'Clé privé l’API',
	'OA_SOCIAL_SHARING_API_PUBLIC_KEY' => 'Clé publique l’API',
	'OA_SOCIAL_SHARING_API_SUBDOMAIN' => 'Sous domaine de l’API',
	'OA_SOCIAL_SHARING_API_VERIFY' => 'Paramètres de vérification de l’API',
	'OA_SOCIAL_SHARING_CREATE_ACCOUNT_FIRST' => 'Pour utiliser la passerelle de connexion OneAll, au préalable il doit être créé un compte gratuit sur <a href="https://app.oneall.com/signup/" class="external">http://www.oneall.com</a> et configurer un site.',
	'OA_SOCIAL_SHARING_CURL' => 'PHP CURL',
	'OA_SOCIAL_SHARING_CURL_DESC' => 'L’utilisation de CURL est recommandé mais peut être désactivé sur certains serveurs.',
	'OA_SOCIAL_SHARING_CURL_DOCS' => '<a href="http://www.php.net/manual/en/book.curl.php" class="external">Manuel de CURL</a>',
	'OA_SOCIAL_SHARING_DEFAULT' => 'Défaut',
	'OA_SOCIAL_SHARING_DISCOVER_PLUGINS' => '<a href="http://docs.oneall.com/plugins/" class="external">Découvrir</a> nos plugins clés en main pour Drupal, Joomla, WordPress.',
	'OA_SOCIAL_SHARING_DISPLAY_LOC' => 'Position de la passerelle de connexion OneAll',
	'OA_SOCIAL_SHARING_DO_AVATARS' => 'Activer l’envoi d’avatars depuis les réseaux sociaux ?',
	'OA_SOCIAL_SHARING_DO_AVATARS_DESC' => 'Permet de récupérer les avatars de l’utilisateur sur ses réseaux sociaux pour les envoyer dans le dossier des avatars de phpBB.',
	'OA_SOCIAL_SHARING_DO_AVATARS_ENABLE_NO' => 'Non, ne pas utiliser les avatars des réseaux sociaux',
	'OA_SOCIAL_SHARING_DO_AVATARS_ENABLE_YES' => 'Oui, utiliser les avatars des réseaux sociaux',
	'OA_SOCIAL_SHARING_DO_ENABLE' => 'Activer la passerelle de connexion OneAll ?',
	'OA_SOCIAL_SHARING_DO_ENABLE_DESC' => 'Permet de désactiver temporairement la passerelle de connexion OneAll sans avoir à l’enlever.',
	'OA_SOCIAL_SHARING_DO_ENABLE_NO' => 'Désactiver',
	'OA_SOCIAL_SHARING_DO_ENABLE_YES' => 'Activer',
	'OA_SOCIAL_SHARING_DO_LINKING' => 'Activer la liaison des comptes avec les réseaux sociaux ?',
	'OA_SOCIAL_SHARING_DO_LINKING_ASK' => 'Lier automatiquement les comptes des réseaux sociaux avec les comptes utilisateurs existants ?',
	'OA_SOCIAL_SHARING_DO_LINKING_DESC' => 'Si activé, les comptes des réseaux sociaux avec une adresse e-mail vérifiée seront liés avec les comptes utilisateurs phpBB existants ayant la même adresse e-mail.',
	'OA_SOCIAL_SHARING_DO_LINKING_NO' => 'Désactiver la liaison des comptes',
	'OA_SOCIAL_SHARING_DO_LINKING_YES' => 'Activer la liaison des comptes',
	'OA_SOCIAL_SHARING_DO_REDIRECT' => 'Redirection',
	'OA_SOCIAL_SHARING_DO_REDIRECT_ASK' => 'Rediriger les utilisateurs vers cette page après avoir été connecté avec leur compte de réseau social',
	'OA_SOCIAL_SHARING_DO_REDIRECT_DESC' => 'Saisir une adresse URL complète vers une page de votre forum phpBB. Si aucune adresse n’est indiquée l’utilisateur restera sur la même page.',
	'OA_SOCIAL_SHARING_DO_VALIDATION' => 'Demander la confirmation du profil aux nouveaux utilisateurs ?',
	'OA_SOCIAL_SHARING_DO_VALIDATION_ALWAYS' => 'Activer la confirmation du profil',
	'OA_SOCIAL_SHARING_DO_VALIDATION_ASK' => 'Demander aux nouveaux utilisateurs de saisir leur nom d’utilisateur et leur adresse e-mail ?',
	'OA_SOCIAL_SHARING_DO_VALIDATION_DEPENDS' => 'Confirmation exceptionnelle du profil',
	'OA_SOCIAL_SHARING_DO_VALIDATION_DESC' => 'Si activé, les nouveaux utilisateurs seront invités à saisir ou confirmer leur nom d’utilisateur et leur adresse e-mail.<br /> Si sélectionnée, une confirmation exceptionnelle sera demandée uniquement si la connexion automatique au réseau social est désactivée, que le nom d’utilisateur est récupéré, que l’adresse e-mail est manquante mais a été récupérée.',
	'OA_SOCIAL_SHARING_DO_VALIDATION_NEVER' => 'Désactiver la confirmation du profil',
	'OA_SOCIAL_SHARING_ENABLE_NETWORKS' => 'Choisir les réseaux sociaux autorisés sur votre forum',
	'OA_SOCIAL_SHARING_ENABLE_SOCIAL_NETWORK' => 'Au moins un réseau social doit être activé',
	'OA_SOCIAL_SHARING_ENTER_CREDENTIALS' => 'Configurer ses certificats d’API',
	'OA_SOCIAL_SHARING_FOLLOW_US_TWITTER' => '<a href="http://www.twitter.com/oneall" class="external">Nous suivre</a> sur Twitter pour rester informé des nouveautés.',
	'OA_SOCIAL_SHARING_FSOCKOPEN' => 'PHP FSOCKOPEN',
	'OA_SOCIAL_SHARING_FSOCKOPEN_DESC' => 'Utiliser uniquement FSOCKOPEN si des problèmes sont rencontrés avec CURL.',
	'OA_SOCIAL_SHARING_FSOCKOPEN_DOCS' => '<a href="http://www.php.net/manual/en/function.fsockopen.php" class="external">Manuel de FSOCKOPEN</a>',
	'OA_SOCIAL_SHARING_GET_HELP' => '<a href="http://www.oneall.com/company/contact-us/" class="external">Nous contacter</a> pour tout commentaire ou demande d’aide !',
	'OA_SOCIAL_SHARING_INDEX_PAGE' => 'Page d’accueil du forum',
	'OA_SOCIAL_SHARING_INDEX_PAGE_CAPTION' => 'Légende',
	'OA_SOCIAL_SHARING_INDEX_PAGE_CAPTION_DESC' => 'Ce titre sera affiché au-dessus des icônes de la passerelle de connexion OneAll sur la page d’accueil du forum.',
	'OA_SOCIAL_SHARING_INDEX_PAGE_ENABLE' => 'Activer la passerelle de connexion OneAll sur la page d’accueil du forum ?',
	'OA_SOCIAL_SHARING_INDEX_PAGE_ENABLE_DESC' => 'Si activé, la passerelle de connexion OneAll sera affichée sur la page d’accueil du forum.',
	'OA_SOCIAL_SHARING_INDEX_PAGE_NO' => 'Désactiver',
	'OA_SOCIAL_SHARING_INDEX_PAGE_YES' => 'Activer',
	'OA_SOCIAL_SHARING_INTRO' => 'Permet aux utilisateurs de se connecter et de s’enregistrer avec les réseaux sociaux tels que Twitter, Facebook, LinkedIn, Hyves, VKontakte, Google et Yahoo et bien d’autres.<br /> La passerelle de connexion OneAll <strong>permet d’augmenter le nombre de nouveaux utilisateurs</strong> en simplifiant l’enregistrement avec des informations <strong>récupérées depuis les profils des réseaux sociaux</strong> (les permissions utilisées sont basiques). La passerelle de connexion OneAll s’intègre au système d’enregistrement actuel du forum ainsi les utilisateurs n’auront pas à recommencer leur enregistrement sur le forum.',
	'OA_SOCIAL_SHARING_LOGIN_PAGE' => 'Page de connexion du forum',
	'OA_SOCIAL_SHARING_LOGIN_PAGE_CAPTION' => 'Légende',
	'OA_SOCIAL_SHARING_LOGIN_PAGE_CAPTION_DESC' => 'Ce titre sera affiché au-dessus des icônes de la passerelle de connexion OneAll sur la page de connexion du forum.',
	'OA_SOCIAL_SHARING_LOGIN_PAGE_ENABLE' => 'Activer la passerelle de connexion OneAll sur la page de connexion du forum ?',
	'OA_SOCIAL_SHARING_LOGIN_PAGE_ENABLE_DESC' => 'Si activé, la passerelle de connexion OneAll sera affichée sur la page de connexion du forum.',
	'OA_SOCIAL_SHARING_LOGIN_PAGE_NO' => 'Désactiver',
	'OA_SOCIAL_SHARING_LOGIN_PAGE_YES' => 'Activer',
	'OA_SOCIAL_SHARING_OTHER_PAGE' => 'Toutes les autres pages du forum',
	'OA_SOCIAL_SHARING_OTHER_PAGE_CAPTION' => 'Légende',
	'OA_SOCIAL_SHARING_OTHER_PAGE_CAPTION_DESC' => 'Ce titre sera affiché au-dessus des icônes de la passerelle de connexion OneAll sur les autres pages du forum.',
	'OA_SOCIAL_SHARING_OTHER_PAGE_ENABLE' => 'Activer la passerelle de connexion OneAll sur les autres pages du forum ?',
	'OA_SOCIAL_SHARING_OTHER_PAGE_ENABLE_DESC' => 'Si activé, la passerelle de connexion OneAll sera affichée sur les autres pages du forum.',
	'OA_SOCIAL_SHARING_OTHER_PAGE_NO' => 'Désactiver',
	'OA_SOCIAL_SHARING_OTHER_PAGE_YES' => 'Activer',
	'OA_SOCIAL_SHARING_PORT_443' => 'Communication via HTTPS sur le port 443',
	'OA_SOCIAL_SHARING_PORT_443_DESC' => 'L’utilisation du port 443 est recommandé, il est possible qu’il soit nécessaire d’installer OpenSSL sur le serveur d’hébergement du forum.',
	'OA_SOCIAL_SHARING_PORT_80' => 'Communication via HTTP sur le port 80',
	'OA_SOCIAL_SHARING_PORT_80_DESC' => 'L’utilisation du port 80 est un peu plus rapide, ne nécessite pas OpenSSL mais est moins sécurisé.',
	'OA_SOCIAL_SHARING_PREVIEW' => 'Aperçu des icônes de partage',
	'OA_SOCIAL_SHARING_PROFILE_DESC' => 'Lier votre compte à un réseau social',
	'OA_SOCIAL_SHARING_PROFILE_TITLE' => 'Passerelle de connexion OneAll',
	'OA_SOCIAL_SHARING_READ_DOCS' => '<a href="http://docs.oneall.com/plugins/" class="external">Lire</a> la documentation en ligne pour en savoir d’avantage sur ce plugin.',
	'OA_SOCIAL_SHARING_REGISTRATION_PAGE' => 'Page d’inscription du forum',
	'OA_SOCIAL_SHARING_REGISTRATION_PAGE_CAPTION' => 'Légende',
	'OA_SOCIAL_SHARING_REGISTRATION_PAGE_CAPTION_DESC' => 'Ce titre sera affiché au-dessus des icônes de la passerelle de connexion OneAll sur la page d’inscription du forum.',
	'OA_SOCIAL_SHARING_REGISTRATION_PAGE_ENABLE' => 'Activer la passerelle de connexion OneAll sur la page d’inscription du forum ?',
	'OA_SOCIAL_SHARING_REGISTRATION_PAGE_ENABLE_DESC' => 'Si activé, la passerelle de connexion OneAll sera affichée sur la page d’inscription du forum.',
	'OA_SOCIAL_SHARING_REGISTRATION_PAGE_NO' => 'Désactiver',
	'OA_SOCIAL_SHARING_REGISTRATION_PAGE_YES' => 'Activer',
	'OA_SOCIAL_SHARING_SETTINGS' => 'Paramètres',
	'OA_SOCIAL_SHARING_SETTINGS_UPDATED' => 'Paramètres mis à jour avec succès.',
	'OA_SOCIAL_SHARING_SETUP_FREE_ACCOUNT' => '<a href="https://app.oneall.com/signup/" class="button1 external">Configurer mon compte gratuit</a>',
	'OA_SOCIAL_SHARING_SOCIAL_LINK' => 'Service de liens sociaux (Social Link)',
	'OA_SOCIAL_SHARING_TITLE' => 'Passerelle de connexion OneAll',
	'OA_SOCIAL_SHARING_TITLE_HELP' => 'Aide, mises à jour &amp; documentation',
	'OA_SOCIAL_SHARING_VALIDATION_FORM_DESC' => 'L’administrateur requiert la saisie de votre nom d’utilisateur et de votre adresse e-mail.',
	'OA_SOCIAL_SHARING_VALIDATION_FORM_EMAIL_EXPLAIN' => 'Accepter ou modifier votre adresse e-mail.',
	'OA_SOCIAL_SHARING_VALIDATION_FORM_EMAIL_NONE_EXPLAIN' => 'Votre profil ne comporte pas d’adresse e-mail, merci d’en saisir une sur cette page.',
	'OA_SOCIAL_SHARING_VALIDATION_FORM_HEADER' => 'Confirmer votre nom d’utilisateur et votre adresse e-mail.',
	'OA_SOCIAL_SHARING_VALIDATION_SESSION_ERROR' => 'Des informations de la session courante sont manquantes.',
	'OA_SOCIAL_SHARING_VIEW_CREDENTIALS' => '<a href="https://app.oneall.com/applications/" class="button1 external">Créer et voir mes certificats d’API</a>',
	'OA_SOCIAL_SHARING_WIDGET_TITLE' => 'Connexion avec un réseau social',
	'G_OA_SOCIAL_SHARING_REGISTER' => 'Utilisateurs inscrits via OneAll',
));
