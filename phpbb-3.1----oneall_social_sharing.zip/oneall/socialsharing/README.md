Social Sharing for phpBB 3.1.x
====================

An installation guide is available here:
http://docs.oneall.com/plugins/
